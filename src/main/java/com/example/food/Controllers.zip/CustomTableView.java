package com.example.food;

import javafx.collections.ObservableList;
import javafx.scene.Node;
import javafx.scene.control.TableView;

public class CustomTableView<T> extends TableView {

    @Override
    public ObservableList<Node> getChildren() {
        return super.getChildren();
    }
}
